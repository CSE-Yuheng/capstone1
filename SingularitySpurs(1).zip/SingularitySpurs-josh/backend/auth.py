"""Login / authentication helpers.

Provides functions to:
 - verify passwords (bcrypt via passlib if available)
 - authenticate a user against the MongoDB `courtside_game_users` collection
 - optionally create a JWT access token (if PyJWT is installed)

This file intentionally provides reusable functions (not FastAPI endpoints).
You can wire these into `app.py` endpoints later.
"""

import os
from typing import Optional, Dict, Any

from pymongo import MongoClient

import hashlib

# Optional dependencies
try:
	from passlib.context import CryptContext
	# prefer bcrypt_sha256 which safely handles arbitrarily long passwords by
	# pre-hashing with SHA-256 before bcrypt (avoids bcrypt's 72-byte limit)
	_pwd_ctx = CryptContext(schemes=["bcrypt_sha256", "bcrypt"], deprecated="auto")
	HAS_PASSLIB = True
except Exception:
	_pwd_ctx = None
	HAS_PASSLIB = False

try:
	import bcrypt as _bcrypt
	HAS_BCRYPT = True
except Exception:
	_bcrypt = None
	HAS_BCRYPT = False

try:
	import jwt
	HAS_PYJWT = True
except Exception:
	jwt = None
	HAS_PYJWT = False

# Config (match seed script defaults)
MONGODB_URI = os.getenv("MONGODB_URI", "mongodb+srv://aregajoshua_db_user:SingularitySpurs25@courtside.ur9oxwi.mongodb.net/")
DB_NAME = os.getenv("DB_NAME", "courtside_game")
JWT_SECRET = os.getenv("JWT_SECRET", "dev_jwt_secret")
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")

# Mongo client
_client = MongoClient(MONGODB_URI)
_db = _client[DB_NAME]
users_col = _db['courtside_game_users']


def verify_password(plain_password: str, stored_password: str) -> bool:
	"""Return True if plain_password matches stored_password.

	Supports passlib bcrypt hashes, raw bcrypt bytes/strings, or plaintext fallback.
	"""
	if not stored_password:
		return False

	# passlib bcrypt (most robust)
	if HAS_PASSLIB and isinstance(stored_password, str) and stored_password.startswith("$2"):
		try:
			return _pwd_ctx.verify(plain_password, stored_password)
		except Exception:
			return False

	# bcrypt module fallback (stored_password may be bytes or str)
	if HAS_BCRYPT:
		try:
			if isinstance(stored_password, str):
				stored_bytes = stored_password.encode()
			else:
				stored_bytes = stored_password
			# First try direct bcrypt check (for legacy stored plain/bcrypt hashes)
			try:
				if _bcrypt.checkpw(plain_password.encode(), stored_bytes):
					return True
			except Exception:
				pass
			# If that fails, try bcrypt on SHA-256(preimage) to support bcrypt_sha256-style
			try:
				sha = hashlib.sha256(plain_password.encode()).digest()
				return _bcrypt.checkpw(sha, stored_bytes)
			except Exception:
				return False
		except Exception:
			return False

	# last-resort plaintext compare (only for PoC)
	return plain_password == stored_password


def get_user_by_username_or_email(username_or_email: str) -> Optional[Dict[str, Any]]:
	"""Lookup a user document by username or email. Returns raw Mongo document or None."""
	if not username_or_email:
		return None
	query = {"$or": [{"username": username_or_email}, {"email": username_or_email}]}
	return users_col.find_one(query)


def authenticate_user(username_or_email: str, password: str) -> Optional[Dict[str, Any]]:
	"""Authenticate against Mongo `courtside_game_users` collection.

	Returns the user document (with password removed) on success, otherwise None.
	"""
	user = get_user_by_username_or_email(username_or_email)
	if not user:
		return None
	stored_pw = user.get("password")
	if verify_password(password, stored_pw):
		# remove password before returning
		user_copy = {k: v for k, v in user.items() if k != "password"}
		return user_copy
	return None


def create_access_token(data: Dict[str, Any], expires_delta: Optional[int] = None) -> Optional[str]:
	"""Create a signed JWT token if PyJWT is available.

	- data: payload to include (will be copied)
	- expires_delta: seconds until expiration (optional)
	Returns token string or None if PyJWT not installed.
	"""
	if not HAS_PYJWT:
		return None
	payload = data.copy()
	import time
	now = int(time.time())
	payload.setdefault("iat", now)
	if expires_delta is not None:
		payload["exp"] = now + int(expires_delta)
	return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def register_user(username: str, email: str, password: str) -> Dict[str, Any]:
	"""Create a new user in the users collection. Returns the inserted doc (without password).

	This function will hash the password using passlib/bcrypt if available; otherwise stores plaintext.
	It raises a ValueError if the username or email already exists.
	"""
	# Basic uniqueness checks
	if users_col.find_one({"username": username}):
		raise ValueError("username_exists")
	if users_col.find_one({"email": email}):
		raise ValueError("email_exists")

	auth_debug = os.getenv("AUTH_DEBUG", "0") in ("1", "true", "True")

	hashed = None
	if HAS_PASSLIB:
		# Try to hash via passlib (prefer bcrypt_sha256 configured above).
		try:
			hashed = _pwd_ctx.hash(password)
			if auth_debug:
				print("auth: register_user - hashed with passlib")
		except Exception as e:
			# If passlib raises an error (e.g., bcrypt length limit), fall back
			# to manual SHA-256 pre-hash + bcrypt if available.
			if auth_debug:
				print("auth: passlib.hash failed, falling back:", repr(e))
			hashed = None

	if hashed is None and HAS_BCRYPT:
		# bcrypt has a 72-byte limit. Pre-hash with SHA-256 (like bcrypt_sha256)
		# so arbitrary-length passwords are supported. Store the resulting bcrypt hash.
		sha = hashlib.sha256(password.encode()).digest()
		hashed = _bcrypt.hashpw(sha, _bcrypt.gensalt())
		if auth_debug:
			print("auth: register_user - hashed with bcrypt over sha256 preimage")

	if hashed is None:
		# final fallback: store plaintext (PoC only)
		if auth_debug:
			print("auth: register_user - falling back to plaintext storage")
		hashed = password

	new_user = {
		"username": username,
		"password": hashed,
		"email": email
	}
	result = users_col.insert_one(new_user)
	# Return user doc with _id (convert ObjectId to string for JSON compatibility)
	new_user["_id"] = str(result.inserted_id)
	return {k: v for k, v in new_user.items() if k != "password"}


__all__ = [
	"verify_password",
	"get_user_by_username_or_email",
	"authenticate_user",
	"create_access_token",
	"register_user",
]

