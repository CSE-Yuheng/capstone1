#!/usr/bin/env python3
"""
Seed teams, picks, games, season and users using an existing players collection.

- Reads existing `players` collection (expects a `team` field on each player).
- Creates `teams` collection with `Roster` = list of player _id values for that team.
- Creates simple `picks` docs and references them from teams.
- Creates `games` (round-robin double-leg) and a `season` document; updates each team's Schedule with game IDs.
- Creates a few demo user accounts.

Usage:
  pip install pymongo faker bcrypt   # bcrypt optional if you want hashed demo passwords
  MONGODB_URI="mongodb://localhost:27017" DB_NAME="courtside_game" python seed_db_schema.py

Environment:
  MONGODB_URI (optional, defaults to localhost)
  DB_NAME (optional, defaults to gm_poc)
  MAX_ROSTER_SIZE (optional, int; if set, cap roster size per team)
  INCLUDE_FREE_AGENT_TEAM (optional, "1" to include a "Free Agent" team document)
"""

import os
import random
import re
import uuid
from datetime import datetime, timedelta
from pymongo import MongoClient

# Optional niceties
try:
    from faker import Faker
    fake = Faker()
except Exception:
    fake = None

try:
    import bcrypt
    HAS_BCRYPT = True
except Exception:
    HAS_BCRYPT = False

# Configuration
MONGODB_URI = os.getenv("MONGODB_URI", "mongodb+srv://aregajoshua_db_user:SingularitySpurs25@courtside.ur9oxwi.mongodb.net/")
DB_NAME = os.getenv("courtside_game", "courtside_game")
MAX_ROSTER_SIZE = int(os.getenv("MAX_ROSTER_SIZE", "17"))  # 0 = no cap, keep all players assigned
INCLUDE_FREE_AGENT_TEAM = os.getenv("INCLUDE_FREE_AGENT_TEAM", "1") in ("1", "true", "True")

SEED = int(os.getenv("SEED", "42"))
random.seed(SEED)

client = MongoClient(MONGODB_URI)
db = client[DB_NAME]

players_col = db['courtside_game_players']      # existing players collection
teams_col = db['courtside_game_teams']
games_col = db['courtside_game_games']
seasons_col = db['courtside_game_seasons']
picks_col = db['courtside_game_picks']
users_col = db['courtside_game_users']
saves_col = db['courtside_game_saves']

# Helpers
def slugify(s: str) -> str:
    """Create a simple safe _id from an arbitrary team name."""
    s = s or ""
    s = s.strip().lower()
    s = re.sub(r"[^\w\s-]", "", s)
    s = re.sub(r"[-\s]+", "_", s)
    if not s:
        s = f"team_{uuid.uuid4().hex[:6]}"
    return f"team_{s}"[:64]

def hash_password(pw: str) -> str:
    if HAS_BCRYPT:
        return bcrypt.hashpw(pw.encode(), bcrypt.gensalt()).decode()
    return pw  # plaintext fallback only for PoC

# 1) Collect players grouped by current `team` field
def build_team_map():
    """
    Returns:
      team_map: { team_name_string: [player_id, ...], ... }
      free_agents: [player_id, ...]  (players with empty/null team)
    """
    team_map = {}
    free_agents = []
    cursor = players_col.find({}, {"_id": 1, "team": 1})
    for doc in cursor:
        pid = doc["_id"]
        team_name = doc.get("team")
        if team_name is None or (isinstance(team_name, str) and team_name.strip() == ""):
            free_agents.append(pid)
        else:
            # normalize team_name into consistent display form (keep original string for name)
            key = team_name.strip()
            team_map.setdefault(key, []).append(pid)
    return team_map, free_agents

# 2) Create teams from the team_map
def create_teams_from_map(team_map, free_agents):
    teams = []
    teams_col.delete_many({})  # optional: reset teams collection for clean seed
    for team_name, player_ids in team_map.items():
        tid = slugify(team_name)
        team_doc = {
            "_id": tid,
            "name": team_name,
            "city": team_name.split()[0] if isinstance(team_name, str) and team_name.strip() else None,
            "wins": 0,
            "losses": 0,
            "Roster": player_ids[:MAX_ROSTER_SIZE] if MAX_ROSTER_SIZE and len(player_ids) > MAX_ROSTER_SIZE else player_ids,
            "capSpace": 154647000,
            "Picks": [],
            "Schedule": []
        }
        teams.append(team_doc)
    # Optionally add a Free Agent bucket so front-end can show them as a "team"
    if INCLUDE_FREE_AGENT_TEAM:
        fa_id = slugify("Free Agent")
        fa_doc = {
            "_id": fa_id,
            "name": "Free Agent",
            "city": None,
            "wins": 0,
            "losses": 0,
            "Roster": free_agents,
            "capSpace": 0.0,
            "Picks": [],
            "Schedule": []
        }
        teams.append(fa_doc)
    if teams:
        teams_col.insert_many(teams)
    return teams

# 3) Create picks and attach to teams
def create_picks_for_teams(teams):
    """
    Create picks for each team: first and second round picks for the next 3 years.
    Clears existing picks to avoid duplicates, and attaches pick ids to each team's
    `Picks` array in the teams collection.
    """
    # Clear old picks so re-running the seeder doesn't accumulate duplicates
    picks_col.delete_many({})

    picks = []
    current_year = datetime.utcnow().year
    years = [current_year + i for i in range(1, 4)]  # next 3 years
    rounds = [1, 2]

    for t in teams:
        for y in years:
            for r in rounds:
                # deterministic-ish id so re-seeds are understandable
                pid = f"pick_{t['_id']}_{r}_{y}"
                pick_doc = {
                    "_id": pid,
                    "teamId": t["_id"],
                    "round": r,
                    "year": y,
                    "notes": "Unprotected (PoC)"
                }
                picks.append(pick_doc)
                teams_col.update_one({"_id": t["_id"]}, {"$push": {"Picks": pick_doc["_id"]}})

    if picks:
        picks_col.insert_many(picks)
    return picks

# 4) Build round-robin schedule (double round: home+away)
# Put these imports at top of file if not already present
import uuid
from datetime import datetime, timedelta, date

# Config: tweak these as you like
MIN_REST_DAYS = 1        # minimum days off between games for any team
SKIP_WEEKENDS = True     # if True, do not schedule games on Saturday/Sunday
START_MONTH = 10
START_DAY   = 21

def is_weekend(d: date):
    return d.weekday() >= 5  # 5=Sat, 6=Sun

def next_calendar_day(d: date):
    return d + timedelta(days=1)

def find_next_valid_date_for_fixture(home, away, last_played, current_date):
    """
    Starting at current_date, find the next date where:
    - if SKIP_WEEKENDS: date is weekday
    - neither team has a game on that date (we track scheduled_by_date)
    - both teams have had at least MIN_REST_DAYS since last_played (if any)
    """
    d = current_date
    while True:
        # optional skip weekends
        if SKIP_WEEKENDS and is_weekend(d):
            d = next_calendar_day(d)
            continue

        # rest constraint
        ok_rest = True
        for t in (home, away):
            last = last_played.get(t)
            if last is not None:
                days_since = (d - last).days
                if days_since <= MIN_REST_DAYS - 1:  # need at least MIN_REST_DAYS full days off
                    ok_rest = False
                    break

        if not ok_rest:
            d = next_calendar_day(d)
            continue

        # neither team should already have a game scheduled that day
        # we'll check scheduled_by_date mapping outside; here just return candidate
        return d

def make_round_robin_and_schedule(teams, start_date=None):
    """
    teams: list of team docs (each must have at least _id and name)
    Returns list of game dicts (insert-ready) and also updates teams' Schedule arrays.
    Behavior:
      - Excludes any team whose name equals "Free Agent" (case-insensitive).
      - Schedules double round-robin.
      - Ensures MIN_REST_DAYS between games per team and optionally skips weekends.
    """
    # Determine start date (Oct 21 current year) if not provided
    current_year = datetime.utcnow().year
    if not start_date:
        start_date = datetime(current_year, START_MONTH, START_DAY).date()

    # Build real teams (exclude Free Agent)
    real_teams = [t for t in teams if not (isinstance(t.get("name"), str) and t["name"].strip().lower() == "free agent")]
    team_ids = [t["_id"] for t in real_teams]
    n = len(team_ids)
    if n < 2:
        return []

    # Build fixtures: each pair twice (home/away)
    fixtures = []
    for i in range(n):
        for j in range(i + 1, n):
            fixtures.append((team_ids[i], team_ids[j]))  # first leg
            fixtures.append((team_ids[j], team_ids[i]))  # return leg

    # Scheduling state
    scheduled_games = []                # result list
    last_played = {}                    # team_id -> date of last game (date object)
    scheduled_by_date = {}              # date.iso -> set(team_id) used that date
    current_date = start_date

    # Iterate fixtures and place them in the calendar
    for (home, away) in fixtures:
        # Find the next date where both teams are available and rested
        # Start searching from current_date
        candidate = current_date
        while True:
            # skip weekends if desired
            if SKIP_WEEKENDS and is_weekend(candidate):
                candidate = next_calendar_day(candidate)
                continue

            # ensure teams don't already have a game that day
            teams_on_date = scheduled_by_date.get(candidate.isoformat(), set())
            if home in teams_on_date or away in teams_on_date:
                candidate = next_calendar_day(candidate)
                continue

            # ensure rest days
            last_home = last_played.get(home)
            last_away = last_played.get(away)
            home_ok = (last_home is None) or ((candidate - last_home).days > MIN_REST_DAYS)
            away_ok = (last_away is None) or ((candidate - last_away).days > MIN_REST_DAYS)
            if not (home_ok and away_ok):
                candidate = next_calendar_day(candidate)
                continue

            # candidate is valid
            break

        # assign game
        game_doc = {
            "_id": f"game_{uuid.uuid4().hex[:8]}",
            "date": candidate.isoformat(),
            "homeTeam": home,
            "awayTeam": away,
            "homeScore": None,
            "awayScore": None,
            "boxScore": [],
            "played": False
        }
        scheduled_games.append(game_doc)

        # record scheduling metadata
        scheduled_by_date.setdefault(candidate.isoformat(), set()).update([home, away])
        last_played[home] = candidate
        last_played[away] = candidate

        # advance current_date by one day so next fixture doesn't try the same day immediately
        current_date = next_calendar_day(candidate)

    return scheduled_games

def create_games_and_assign_schedule(teams):
    """
    Wrapper: generate games with make_round_robin_and_schedule, insert into DB, update teams' Schedule.
    This function will:
      - clear old games (if desired)
      - assign Schedule arrays for all teams (including Free Agent team left unchanged if desired)
    """
    # Optionally clear existing games
    games_col.delete_many({})

    # Reset Schedule arrays for all teams to empty (so we rebuild fresh)
    for t in teams:
        teams_col.update_one({"_id": t["_id"]}, {"$set": {"Schedule": []}})

    # Generate schedule only for real teams
    games = make_round_robin_and_schedule(teams)

    if games:
        games_col.insert_many(games)

    # Update each team's Schedule in DB (only for teams that actually have games)
    for g in games:
        teams_col.update_one({"_id": g["homeTeam"]}, {"$push": {"Schedule": g["_id"]}})
        teams_col.update_one({"_id": g["awayTeam"]}, {"$push": {"Schedule": g["_id"]}})

    return games



# 5) Create a season doc
def create_season_doc(teams, games):
    seasons_col.delete_many({})
    season_doc = {
        "_id": f"season_{datetime.utcnow().year}",
        "leagueId": "league_1",
        "teams": [t["_id"] for t in teams],
        "games": [g["_id"] for g in games],
        "status": "ongoing",
        "createdAt": datetime.utcnow().isoformat()
    }
    seasons_col.insert_one(season_doc)
    return season_doc

# 6) Create demo users
def create_demo_users(n=2):
    users_col.delete_many({})
    users = []
    for i in range(n):
        uname = fake.user_name() if fake else f"user{i+1}"
        pw = f"pass{i+1}1234"
        user = {
            "UUID": f"user_{uuid.uuid4().hex[:8]}",
            "username": uname,
            "password": hash_password(pw),
            "email": fake.email() if fake else f"{uname}@example.com"
        }
        users.append(user)
    if users:
        users_col.insert_many(users)
    return users


def create_save_files_for_users(users, teams, games, picks):
    """
    Create 3 save files per user. Each save file stores references to collections
    (players, teams, games, schedules, picks) as arrays. Also updates each user
    document to include a `saveFiles` array containing the save IDs.
    """
    # Clear existing saves for a fresh seed
    saves_col.delete_many({})

    # Gather current ids from collections
    all_player_ids = [p["_id"] for p in players_col.find({}, {"_id": 1})]
    team_ids = [t["_id"] for t in teams_col.find({}, {"_id": 1})]
    game_ids = [g["_id"] for g in games_col.find({}, {"_id": 1})]
    pick_ids = [p["_id"] for p in picks_col.find({}, {"_id": 1})]

    created_saves = []
    for user in users:
        user_save_ids = []
        for i in range(3):
            sid = f"save_{uuid.uuid4().hex[:8]}"

            # schedule snapshot: map team_id -> Schedule array
            schedule_snapshot = {}
            for t in teams_col.find({}, {"_id": 1, "Schedule": 1}):
                schedule_snapshot[t["_id"]] = t.get("Schedule", [])

            save_doc = {
                "_id": sid,
                "name": f"{user.get('username')}_save_{i+1}",
                "userId": user["UUID"],
                "createdAt": datetime.utcnow().isoformat(),
                "players": all_player_ids,
                "teams": team_ids,
                "games": game_ids,
                "schedules": schedule_snapshot,
                "picks": pick_ids,
                "meta": {"seed": SEED, "notes": "Auto-generated demo save"}
            }

            created_saves.append(save_doc)
            user_save_ids.append(sid)

        # attach save file ids to the user doc
        users_col.update_one({"UUID": user["UUID"]}, {"$set": {"saveFiles": user_save_ids}})

    if created_saves:
        saves_col.insert_many(created_saves)
    return created_saves

# 7) Indexes for faster queries
def create_indexes():
    teams_col.create_index([("name", 1)], unique=True)
    players_col.create_index([("team", 1)])
    players_col.create_index([("name", 1)])
    games_col.create_index([("date", 1)])
    users_col.create_index([("UUID", 1)], unique=True)
    saves_col.create_index([("userId", 1)])
    # Prevent accidental duplicate picks for the same team/round/year
    picks_col.create_index([("teamId", 1), ("round", 1), ("year", 1)], unique=True)

# Main
def main():
    print("Seeding using existing players collection:", MONGODB_URI, " DB:", DB_NAME)
    team_map, free_agents = build_team_map()
    print("Found teams:", len(team_map), "free agents:", len(free_agents))

    teams = create_teams_from_map(team_map, free_agents)
    print("Created teams:", len(teams))

    picks = create_picks_for_teams(teams)
    print("Created picks:", len(picks))

    games = create_games_and_assign_schedule(teams)
    print("Created games:", len(games))

    season = create_season_doc(teams, games)
    print("Created season:", season["_id"])

    users = create_demo_users(n=3)
    print("Created demo users:", len(users))

    # Create save files (3 per user) that snapshot current collections and
    # attach save file IDs to each user document under `saveFiles`.
    saves = create_save_files_for_users(users, teams, games, picks)
    print("Created save files:", len(saves))

    create_indexes()
    print("Indexes created.")

    # Summary & verification hints
    print("--- Summary ---")
    print("teams count:", teams_col.count_documents({}))
    print("players count (unchanged):", players_col.count_documents({}))
    print("games count:", games_col.count_documents({}))
    print("season id:", season["_id"])
    print("Example team doc:", teams_col.find_one({}))
    print("Done.")

if __name__ == "__main__":
    main()
