# cd backend
# pip install -r requirements.txt
# pip install pymongo pyjwt bcrypt
# uvicorn app:app --reload

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import json
import os

app = FastAPI()

# Allow frontend requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

USER_FILE = "users.json"


# Try to use the Mongo-backed auth helpers if available; otherwise fallback to
# the simple file-based implementation that existed previously. Import errors
# (for example missing pymongo) will be caught and the fallback will be used.
try:
    from auth import authenticate_user, create_access_token, register_user  # type: ignore
    HAS_MONGO_AUTH = True
except Exception:
    authenticate_user = None
    create_access_token = None
    register_user = None
    HAS_MONGO_AUTH = False


class LoginRequest(BaseModel):
    username: str
    password: str


class RegisterRequest(BaseModel):
    username: str
    password: str
    email: Optional[str] = None


def load_users():
    if not os.path.exists(USER_FILE):
        return {}
    with open(USER_FILE, "r") as f:
        return json.load(f)


def save_users(users):
    with open(USER_FILE, "w") as f:
        json.dump(users, f, indent=4)


@app.post("/register", status_code=201)
def register(req: RegisterRequest):
    # Prefer Mongo-backed registration when available
    auth_debug = os.getenv("AUTH_DEBUG", "0") in ("1", "true", "True")
    if HAS_MONGO_AUTH and register_user is not None:
        try:
            email = req.email if req.email else f"{req.username}@example.com"
            user = register_user(req.username, email, req.password)
            # Return only JSON-serializable fields (no binary password)
            safe_user = {k: v for k, v in user.items() if k != "password"}
            if "_id" in safe_user and hasattr(safe_user["_id"], "__str__"):
                safe_user["_id"] = str(safe_user["_id"])
            return {"message": "User registered", "user": safe_user}
        except ValueError as e:
            detail = str(e)
            if detail == "username_exists":
                raise HTTPException(status_code=400, detail="User already exists")
            if detail == "email_exists":
                raise HTTPException(status_code=400, detail="Email already registered")
            raise HTTPException(status_code=400, detail=detail)
        except Exception as e:
            # Unexpected server error during registration - log and return generic 500.
            import traceback
            traceback.print_exc()
            if auth_debug:
                raise HTTPException(status_code=500, detail=str(e))
            raise HTTPException(status_code=500, detail="Internal server error during registration")

    # Fallback file-based registration (no hashing)
    try:
        users = load_users()
        if req.username in users:
            raise HTTPException(status_code=400, detail="User already exists")
        users[req.username] = {"password": req.password, "email": req.email}
        save_users(users)
        return {"message": "User registered successfully"}
    except Exception as e:
        import traceback
        traceback.print_exc()
        if auth_debug:
            raise HTTPException(status_code=500, detail=str(e))
        raise HTTPException(status_code=500, detail="Internal server error during registration")


@app.get("/auth/status")
def auth_status():
    """Diagnostic endpoint: shows which auth backend is active and library versions."""
    status = {"HAS_MONGO_AUTH": HAS_MONGO_AUTH}
    
    if HAS_MONGO_AUTH:
        try:
            from auth import HAS_PASSLIB, HAS_BCRYPT, HAS_PYJWT
            status["HAS_PASSLIB"] = HAS_PASSLIB
            status["HAS_BCRYPT"] = HAS_BCRYPT
            status["HAS_PYJWT"] = HAS_PYJWT
        except Exception:
            pass
    
    return status


@app.post("/login")
def login(req: LoginRequest):
    auth_debug = os.getenv("AUTH_DEBUG", "0") in ("1", "true", "True")
    # Prefer Mongo-backed authentication when available
    try:
        if HAS_MONGO_AUTH and authenticate_user is not None:
            user = authenticate_user(req.username, req.password)
            if not user:
                raise HTTPException(status_code=401, detail="Invalid credentials")
            # Sanitize user dict: exclude password, convert _id to string for JSON
            safe_user = {k: v for k, v in user.items() if k != "password"}
            if "_id" in safe_user and hasattr(safe_user["_id"], "__str__"):
                safe_user["_id"] = str(safe_user["_id"])
            token = None
            if create_access_token is not None:
                # Use _id as the subject instead of UUID
                token = create_access_token({"sub": str(safe_user.get("_id", ""))}, expires_delta=3600)
            return {"message": "Login successful", "user": safe_user, "access_token": token}

        # Fallback file-based login
        users = load_users()
        if req.username not in users or users[req.username]["password"] != req.password:
            raise HTTPException(status_code=401, detail="Invalid credentials")
        return {"message": "Login successful"}
    except HTTPException:
        # re-raise intended HTTP errors
        raise
    except Exception as e:
        import traceback
        traceback.print_exc()
        if auth_debug:
            raise HTTPException(status_code=500, detail=str(e))
        raise HTTPException(status_code=500, detail="Internal server error during login")
