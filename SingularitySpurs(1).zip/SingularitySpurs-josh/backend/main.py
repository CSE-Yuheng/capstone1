from fastapi import FastAPI, HTTPException
from enum import Enum
from pydantic import BaseModel
from typing import Union

app = FastAPI()

class Position(Enum) :
    CENTER = "C"
    POWER_FORWARD = "PF"
    SMALL_FORWARD = "SF"
    SHOOT_GUARD = "SG"
    POINT_GUARD = "PG"

class Player(BaseModel):
    name: str
    age: int
    num: int
    position: Position
    id: int

players = {
    0: Player(name="LeBron James", age=40, num=23, position = Position.SMALL_FORWARD, id=0),
    1: Player(name="Luka Doncic", age=26, num=77, position = Position.POINT_GUARD, id=1),
    2: Player(name="Austin Reaves", age=27, num=15, position = Position.SHOOT_GUARD, id=2),
    3: Player(name="Deandre Ayton", age=27, num=5, position = Position.CENTER, id=3),
    4: Player(name="Rui Hachimura", age=27, num=28, position = Position.POWER_FORWARD, id=4),
}

@app.get("/")
def index() -> dict[str, dict[int, Player]]:
    return {"players": players}

@app.get("/players/{player_id}")
def query_player_by_id(player_id: int) -> Player:
    if player_id not in players:
        raise HTTPException(
            status_code=404, detail=f"Player with {player_id=} does not exist."
        )
    return players[player_id]

Selection = dict[str, Union[str, int, Position, None]]

@app.get("/players/")
def query_player_by_parameters(
    name: str | None = None, 
    age: int | None = None, 
    num: int | None = None, 
    position: Position | None = None, 
    id: int | None = None,
) -> dict[str, Selection | list[Player]]:
    def check_player(player: Player):
        return all(
            (
                name is None or player.name == name,
                age is None or player.age == age,
                num is None or player.num == num,
                position is None or player.position is position,
                id is None or player.id == id,
            )
        )
    
    selection = [player for player in players.values() if check_player(player)]
    return {
        "query": {"name": name, "age": age, "num": num, "position": position, "id": id},
        "selection": selection,
    }

                