# SingularitySpurs
# Courtside 

Courtside is a basketball management app that will allow users to create, play games, and grow the skills of their basketball team.



Your audience for the Readme.md are other developers who are joining your team.
Specifically, the file should contain detailed instructions that any developer
can follow to install, compile, run, and test your project. These are not only
useful to new developers, but also to you when you have to re-install everything
because your old laptop crashed. Also, the teachers of this class will be
following your instructions.

## External Requirements

You must have these installed to build the project:
- Node.js
- Python 3.9+
- Git

## Setup

- Create a personal folder to clone github repo in,
- Check all necessary programs are installed,
- Create your own personal branch to push from
- Run locally to test

## Running

To run locally for viewing, run:
cd frontend
npm install
npm start
--- it will open at http://localhost:3000

To run migrations and start the dev server in python:
python manage.py migrate
python manage.py runserver 8000


# Deployment

To deploy on Render:
- In dashboard, go to New, Static Site, connect your Git provider, and select the repo and branch
- Set the fields:
    - Build Command: yarn; yarn build OR npm install && npm run build
    - Publish Directory: frontend/build
- Click Create

# Testing

In 492 you will write automated tests. When you do you will need to add a
section that explains how to run them.

The unit tests are in `/test/unit`.

The behavioral tests are in `/test/casper/`.

## Testing Technology

In some cases you need to install test runners, etc. Explain how.

## Running Tests

Explain how to run the automated tests.

# Style Guide

https://google.github.io/styleguide/pyguide.html

# Authors

Joshua Arega, Jack Hendley, Sean Nary, Victoria Vanlue, Yuheng Zhu
