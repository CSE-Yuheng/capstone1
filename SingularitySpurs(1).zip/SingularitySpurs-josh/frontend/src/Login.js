import React, { useState } from "react";
import "./Login.css";
import './variables.css';

const Login = () => {
  const [formData, setFormData] = useState({ username: "", password: "" });
  const [error, setError] = useState("");

  const handleChange = (e) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    try {
      const response = await fetch("http://localhost:8000/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const data = await response.json();
        setError(data.detail || "Server error");
        return;
      }

      const data = await response.json();
      alert(`Welcome ${data.username}!`);

      // Handle successful login logic here once we set up mongodb stuff

    } catch {
      setError("Server error");
    }
  };

  return (
    <div className="login-wrapper">
      <div className="login-header">
        <img
          src="./images/logo.svg"
          alt="Logo"
          className="logo"
        />
        <h1 className="logo-text">Courtside</h1>
      </div>

      {/* Titles above the container */}
      <div className="login-titles">
        <h2 className="login-title">Log In</h2>
        <p className="login-subtitle">Log in to continue your basketball experience.</p>
      </div>

      <div className="login-container">
        <form onSubmit={handleSubmit} className="login-form">
          {/* Username field */}
          <label htmlFor="username" className="input-label">
            Username or Email
          </label>
          <input
            id="username"
            name="username"
            type="text"
            placeholder="example@gmail.com"
            value={formData.username}
            onChange={handleChange}
            required
          />

          {/* Password label + forgot link inline */}
          <div className="password-label-wrapper">
            <label htmlFor="password" className="input-label">
              Password
            </label>
            <a href="#" className="forgot-link">
              Forgot Your Password?
            </a>
          </div>
          <input
            id="password"
            name="password"
            type="password"
            placeholder="Password"
            value={formData.password}
            onChange={handleChange}
            required
          />

          <button type="submit" className="login-button">
            Log In
          </button>
        </form>

        {error && <p className="error-message">{error}</p>}

        <p className="signup-text">
          Don’t have an account? <a href="#">Sign Up</a>
        </p>
      </div>
    </div>
  );
};

export default Login;
